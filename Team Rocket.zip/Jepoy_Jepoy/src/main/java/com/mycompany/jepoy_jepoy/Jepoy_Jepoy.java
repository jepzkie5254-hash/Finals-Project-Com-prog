/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jepoy_jepoy;

/**
 *
 * @author Admin
 */
public class Jepoy_Jepoy {

    public static void main(String[] args) {
        
        
        System.out.println("Hello World");

    
    
    }
}
